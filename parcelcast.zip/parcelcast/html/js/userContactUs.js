
$(document).ready(function() {
	var w_height = $(window).height();
	//ship-review page
	$('body').css({'height':w_height});
});